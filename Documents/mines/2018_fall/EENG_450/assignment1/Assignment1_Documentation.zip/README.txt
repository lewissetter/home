TITLE: Documentation for intro to Pi assignment
AUTHOR: Lewis Setter
LAST EDIT: Aug 27, 2018

This assignment consits of the following files:

IntroToPi.py:
A Python script which accomplishes the tasks required by the intro to pi
assignment. To achieve the intended result, the user must execute the program from the
command line within the same directory as "datafile.txt".

ANSWERS.pdf:
Contains detailed answers to the questions from the intro to pi assignment.

Design_Scenario_Response.pdf:
Contains a detailed response to the design scenario presented in the intro to pi
assignment.
